package work.model.service;

import java.util.ArrayList;
import java.util.Iterator;

import work.model.dao.BboardDao;
import work.model.dto.Bboard;

public class BboardService {
	private BboardDao bbdao = BboardDao.getInstance();

	/**
	 * <pre>
	 * 전체목록 조회
	 * </pre>
	 * @param num
	 * @return 게시판 목록
	 */
	public ArrayList bboardSelectAll(int num, int page) {
		ArrayList al;
		al = bbdao.selectAll(num, page);
		if (al.size() > 0) {
			return al;
		}
		return null;
	}
	
	/**
	 * <pre>
	 * 전체 개수 조회
	 * </pre>
	 * @return 총 개수
	 */
	public int bboardLast() {
		return bbdao.selectLast();
	}
	
}
